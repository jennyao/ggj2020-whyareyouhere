class TopLocationsModel {
  TopLocationsModel(this.categoryId);

  final int categoryId;
}
