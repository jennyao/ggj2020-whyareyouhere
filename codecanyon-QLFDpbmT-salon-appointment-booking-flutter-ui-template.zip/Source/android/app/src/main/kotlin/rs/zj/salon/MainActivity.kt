package rs.zj.salon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
